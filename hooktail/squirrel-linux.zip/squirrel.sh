#!/bin/sh
echo -ne '\033c\033]0;Hooktail- A Tale of a Squirrel\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/squirrel.x86_64" "$@"
